using System;
using System.Collections.Generic;
using System.Linq;
using Hz.Memory;
using Hz.Offsets;
using Hz.Structs;

namespace Hz.ESP
{
    public class ESPEngine
    {
        private MemoryReader _memoryReader;
        private List<Entity> _visibleEntities;
        private readonly object _lockObject = new object();
        
        public bool IsRunning { get; private set; }
        public int EntityCount => _visibleEntities?.Count ?? 0;
        
        public ESPEngine(MemoryReader memoryReader)
        {
            _memoryReader = memoryReader;
            _visibleEntities = new List<Entity>();
        }
        
        public void Start()
        {
            IsRunning = true;
        }
        
        public void Stop()
        {
            IsRunning = false;
            lock (_lockObject)
            {
                _visibleEntities.Clear();
            }
        }
        
        public void ScanPlayers(IntPtr playerListAddress, int maxPlayers = 256)
        {
            if (!IsRunning || _memoryReader == null) return;
            
            lock (_lockObject)
            {
                _visibleEntities.RemoveAll(e => e.Type == EntityType.Player);
            }
            
            for (int i = 0; i < maxPlayers; i++)
            {
                IntPtr playerPtr = _memoryReader.ReadIntPtr(playerListAddress + (uint)(i * IntPtr.Size));
                if (playerPtr == IntPtr.Zero) continue;
                
                var entity = new Entity(playerPtr, EntityType.Player)
                {
                    Position = _memoryReader.ReadVector3(playerPtr + PlayerOffsets.Position),
                    Health = _memoryReader.ReadFloat(playerPtr + PlayerOffsets.Health),
                    IsAlive = !_memoryReader.ReadBool(playerPtr + PlayerOffsets.IsDead),
                    Distance = _memoryReader.ReadFloat(playerPtr + PlayerOffsets.Distance)
                };
                
                if (entity.IsAlive && entity.Health > 0)
                {
                    lock (_lockObject)
                    {
                        _visibleEntities.Add(entity);
                    }
                }
            }
        }
        
        public void ScanAnimals(IntPtr animalListAddress, int maxAnimals = 128)
        {
            if (!IsRunning || _memoryReader == null) return;
            
            lock (_lockObject)
            {
                _visibleEntities.RemoveAll(e => e.Type == EntityType.Animal);
            }
            
            for (int i = 0; i < maxAnimals; i++)
            {
                IntPtr animalPtr = _memoryReader.ReadIntPtr(animalListAddress + (uint)(i * IntPtr.Size));
                if (animalPtr == IntPtr.Zero) continue;
                
                var entity = new Entity(animalPtr, EntityType.Animal)
                {
                    Position = _memoryReader.ReadVector3(animalPtr + AnimalOffsets.Position),
                    Health = _memoryReader.ReadFloat(animalPtr + AnimalOffsets.Health),
                    IsAlive = true,
                    Distance = 0
                };
                
                lock (_lockObject)
                {
                    _visibleEntities.Add(entity);
                }
            }
        }
        
        public void ScanContainers(IntPtr containerListAddress, int maxContainers = 512)
        {
            if (!IsRunning || _memoryReader == null) return;
            
            lock (_lockObject)
            {
                _visibleEntities.RemoveAll(e => e.Type == EntityType.Container);
            }
            
            for (int i = 0; i < maxContainers; i++)
            {
                IntPtr containerPtr = _memoryReader.ReadIntPtr(containerListAddress + (uint)(i * IntPtr.Size));
                if (containerPtr == IntPtr.Zero) continue;
                
                var entity = new Entity(containerPtr, EntityType.Container)
                {
                    Position = _memoryReader.ReadVector3(containerPtr + ContainerOffsets.Position),
                    Health = 0,
                    IsAlive = true,
                    Distance = 0
                };
                
                lock (_lockObject)
                {
                    _visibleEntities.Add(entity);
                }
            }
        }
        
        public void ScanResources(IntPtr resourceListAddress, int maxResources = 1024)
        {
            if (!IsRunning || _memoryReader == null) return;
            
            lock (_lockObject)
            {
                _visibleEntities.RemoveAll(e => e.Type == EntityType.Resource);
            }
            
            for (int i = 0; i < maxResources; i++)
            {
                IntPtr resourcePtr = _memoryReader.ReadIntPtr(resourceListAddress + (uint)(i * IntPtr.Size));
                if (resourcePtr == IntPtr.Zero) continue;
                
                var entity = new Entity(resourcePtr, EntityType.Resource)
                {
                    Position = _memoryReader.ReadVector3(resourcePtr + ResourceOffsets.Position),
                    Health = _memoryReader.ReadFloat(resourcePtr + ResourceOffsets.Health),
                    IsAlive = true,
                    Distance = 0
                };
                
                lock (_lockObject)
                {
                    _visibleEntities.Add(entity);
                }
            }
        }
        
        public List<Entity> GetVisibleEntities()
        {
            lock (_lockObject)
            {
                return new List<Entity>(_visibleEntities);
            }
        }
        
        public List<Entity> GetPlayersByType(EntityType type)
        {
            lock (_lockObject)
            {
                return _visibleEntities.Where(e => e.Type == type).ToList();
            }
        }
    }
}