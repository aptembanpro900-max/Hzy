namespace Hz.Offsets
{
    /// <summary>
    /// Оффсеты для структуры Aimbot (кости для наведения)
    /// </summary>
    public class AimbotOffsets
    {
        // Кости персонажа для наведения
        public const uint SkeletonRoot = 0x150;
        
        // Основные точки прицеливания
        public const uint Head_Bone = 0x158;         // Голова (лучшая точка)
        public const uint Neck_Bone = 0x168;         // Шея
        public const uint Spine_Bone = 0x160;        // Позвоночник/Грудь
        public const uint LeftArm_Bone = 0x180;      // Левая рука
        public const uint RightArm_Bone = 0x188;     // Правая рука
        public const uint LeftLeg_Bone = 0x190;      // Левая нога
        public const uint RightLeg_Bone = 0x198;     // Правая нога
        
        // FOV для aimbot
        public const float AimbotFOV = 45f;          // градусы
        public const float MaxDistance = 500f;       // максимальное расстояние
        
        public enum BoneType
        {
            Head = 0,
            Neck = 1,
            Spine = 2,
            LeftArm = 3,
            RightArm = 4,
            LeftLeg = 5,
            RightLeg = 6
        }
    }
}