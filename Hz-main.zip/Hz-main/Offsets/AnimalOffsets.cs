namespace Hz.Offsets
{
    /// <summary>
    /// Оффсеты для структуры Animal (животные)
    /// </summary>
    public class AnimalOffsets
    {
        // Базовая структура животного
        public const uint AnimalBase = 0x0;
        public const uint Position = 0x18;           // Vector3 позиция
        public const uint Health = 0x140;            // float - здоровье
        public const uint Species = 0x200;           // enum - тип животного
        
        // Типы животных
        public enum AnimalType
        {
            Bear = 1,
            Wolf = 2,
            Deer = 3,
            Chicken = 4,
            Boar = 5,
            Horse = 6
        }
    }
}