namespace Hz.Offsets
{
    /// <summary>
    /// Оффсеты для структуры BasePlayer
    /// </summary>
    public class PlayerOffsets
    {
        // Основная позиция
        public const uint Position = 0x18;           // Vector3 - координаты X, Y, Z
        public const uint Transform = 0x10;          // Transform компонент
        
        // Здоровье и статус
        public const uint Health = 0x140;            // float - текущее здоровье
        public const uint MaxHealth = 0x144;         // float - максимальное здоровье
        public const uint IsDead = 0x148;            // bool - жив ли игрок
        
        // Кости скелета (для aim)
        public const uint BoneTransforms = 0x150;    // массив Transform для костей
        public const uint Head = 0x158;              // Bone_Head
        public const uint Chest = 0x160;             // Bone_Chest
        public const uint Neck = 0x168;              // Bone_Neck
        
        // Видимость
        public const uint PlayerModel = 0x170;       // GameObject для визуализации
        public const uint IsVisible = 0x178;         // bool
        public const uint Distance = 0x180;          // float - расстояние до игрока
    }
}