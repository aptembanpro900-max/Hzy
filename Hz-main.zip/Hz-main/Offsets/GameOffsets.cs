using System;

namespace Hz.Offsets
{
    /// <summary>
    /// Оффсеты для памяти игры Oxide Survival Island на Android
    /// </summary>
    public class GameOffsets
    {
        // Player структура
        public const long PlayerListPtr = 0x0;          // Указатель на список игроков
        public const long PlayerBaseOffset = 0x0;        // Базовый оффсет Player

        // Позиция и трансформ
        public const long PositionOffset = 0x18;         // Vector3 - XYZ
        public const long RotationOffset = 0x24;         // Rotation

        // Здоровье
        public const long HealthOffset = 0x140;          // float - текущее здоровье
        public const long MaxHealthOffset = 0x144;       // float - макс здоровье
        public const long IsDeadOffset = 0x148;          // bool - жив ли

        // Кости (для Aimbot)
        public const long BoneTransformsOffset = 0x150;  // массив Transform
        public const long HeadBoneOffset = 0x158;         // Голова
        public const long ChestBoneOffset = 0x160;        // Грудь
        public const long NeckBoneOffset = 0x168;         // Шея
        public const long LeftArmOffset = 0x180;          // Левая рука
        public const long RightArmOffset = 0x188;         // Правая рука
        public const long LeftLegOffset = 0x190;          // Левая нога
        public const long RightLegOffset = 0x198;         // Правая нога

        // Видимость
        public const long IsVisibleOffset = 0x178;       // bool
        public const long DistanceOffset = 0x180;         // float

        // Ресурсы
        public const long ResourceTypeOffset = 0x2C0;     // enum - тип ресурса
        public const long ResourceAmountOffset = 0x2C8;   // int - количество
        public const long ResourceHealthOffset = 0x2CC;   // float - здоровье

        // Контейнеры
        public const long ContainerTypeOffset = 0x280;    // enum - тип контейнера
        public const long IsLockedOffset = 0x290;         // bool - заблокирован
        public const long ItemsCountOffset = 0x2A8;       // int - кол-во предметов
    }

    public enum ResourceType
    {
        Stone = 1,
        Wood = 2,
        Sulfur = 3,
        IronOre = 4,
        Copper = 5,
        Crude = 6,
        Metal = 7
    }

    public enum ContainerType
    {
        WoodenBox = 1,
        MilitaryCrate = 2,
        ToolBox = 3,
        EliteCrate = 4,
        Fridge = 5,
        Furnace = 6
    }
}
