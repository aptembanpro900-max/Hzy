namespace Hz.Offsets
{
    /// <summary>
    /// Оффсеты для структуры NPC
    /// </summary>
    public class NPCOffsets
    {
        public const uint Position = 0x18;           // Vector3
        public const uint Health = 0x140;            // float
        public const uint NPCType = 0x210;           // enum - тип NPC
        public const uint Brain = 0x220;             // AI мозг
        public const uint Inventory = 0x230;         // Инвентарь NPC
        
        // Типы NPC
        public enum NPCType
        {
            Scientist = 1,
            Bandit = 2,
            Murderer = 3,
            Guard = 4
        }
    }
}