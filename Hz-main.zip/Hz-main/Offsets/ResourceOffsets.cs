namespace Hz.Offsets
{
    /// <summary>
    /// Оффсеты для структуры Resource (руда, дерево, камень)
    /// </summary>
    public class ResourceOffsets
    {
        public const uint Position = 0x18;           // Vector3
        public const uint ResourceType = 0x2C0;      // enum - тип ресурса
        public const uint Amount = 0x2C8;            // int - количество
        public const uint Health = 0x2CC;            // float - здоровье ноды
        
        // Типы ресурсов
        public enum ResourceType
        {
            Stone = 1,               // Камень
            Wood = 2,                // Дерево
            Sulfur = 3,              // Серная руда (Sulfur Ore)
            IronOre = 4,             // Железная руда (Iron Ore)
            Copper = 5,              // Медь
            Crude = 6,               // Нефть
            Metal = 7                // Металлический фрагмент
        }
    }
}