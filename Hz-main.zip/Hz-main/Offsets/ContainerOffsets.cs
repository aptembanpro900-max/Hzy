namespace Hz.Offsets
{
    /// <summary>
    /// Оффсеты для структуры Container (ящики, сундуки)
    /// </summary>
    public class ContainerOffsets
    {
        public const uint Position = 0x18;           // Vector3
        public const uint ContainerType = 0x280;     // enum - тип контейнера
        public const uint IsLocked = 0x290;          // bool
        public const uint Inventory = 0x2A0;         // InventoryContainer
        public const uint ItemsCount = 0x2A8;        // int
        
        // Типы контейнеров
        public enum ContainerType
        {
            WoodenBox = 1,           // Деревянный ящик
            MilitaryCrate = 2,       // Военный ящик
            ToolBox = 3,             // Ящик с инструментами
            EliteCrate = 4,          // Элитный ящик
            Fridge = 5,              // Холодильник
            Furnace = 6              // Печь
        }
    }
}