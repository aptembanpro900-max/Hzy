using System;
using System.Collections.Generic;

namespace Hz.Scanning
{
    /// <summary>
    /// Сканирует дампы и находит классы, структуры и оффсеты
    /// </summary>
    public class OffsetScanner
    {
        /// <summary>
        /// Сканирует дампы и находит Player классы
        /// </summary>
        public static List<string> FindPlayerClasses(string dumpContent)
        {
            var results = new List<string>();
            string[] lines = dumpContent.Split('\n');
            
            foreach (var line in lines)
            {
                if (line.Contains("class") && line.Contains("Player"))
                {
                    results.Add(line);
                }
            }
            
            return results;
        }
        
        /// <summary>
        /// Находит все Entity классы (Animal, NPC, Container)
        /// </summary>
        public static List<string> FindEntityClasses(string dumpContent)
        {
            var results = new List<string>();
            string[] lines = dumpContent.Split('\n');
            
            var entityTypes = new[] 
            { 
                "BaseEntity", "Animal", "NPC", "BaseCombatEntity",
                "StorageContainer", "LootContainer", "ResourceDispenser"
            };
            
            foreach (var line in lines)
            {
                foreach (var entityType in entityTypes)
                {
                    if (line.Contains("class") && line.Contains(entityType))
                    {
                        results.Add(line);
                        break;
                    }
                }
            }
            
            return results;
        }
        
        /// <summary>
        /// Находит Transform и Position определения
        /// </summary>
        public static Dictionary<string, string> FindPositionStructures(string dumpContent)
        {
            var results = new Dictionary<string, string>();
            string[] lines = dumpContent.Split('\n');
            
            for (int i = 0; i < lines.Length; i++)
            {
                if (lines[i].Contains("position") || lines[i].Contains("Position"))
                {
                    string context = $"{(i > 0 ? lines[i-1] : "")} | {lines[i]} | {(i < lines.Length-1 ? lines[i+1] : "")}";
                    results.Add($"Line_{i}", context);
                }
            }
            
            return results;
        }
        
        /// <summary>
        /// Получает значение оффсета по имени
        /// </summary>
        public static uint GetOffset(string offsetName)
        {
            return offsetName.ToLower() switch
            {
                "position" => 0x18,
                "health" => 0x140,
                "maxhealth" => 0x144,
                "isdead" => 0x148,
                "head" => 0x158,
                "chest" => 0x160,
                "neck" => 0x168,
                _ => 0
            };
        }
    }
}