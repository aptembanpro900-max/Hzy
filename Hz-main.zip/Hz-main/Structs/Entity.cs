using System;
using Hz.Offsets;
using Hz.Structs;

namespace Hz.Structs
{
    public class Entity
    {
        public IntPtr Address { get; set; }
        public EntityType Type { get; set; }
        public Vector3 Position { get; set; }
        public float Health { get; set; }
        public float Distance { get; set; }
        public bool IsAlive { get; set; }
        public string Name { get; set; }
        
        public Entity(IntPtr address, EntityType type)
        {
            Address = address;
            Type = type;
            Name = type.ToString();
        }
    }
    
    public enum EntityType
    {
        Player,
        Animal,
        NPC,
        Container,
        Resource
    }
}