using System;
using System.Runtime.InteropServices;
using Android.OS;

namespace Hz.Memory
{
    public class MemoryAccessor
    {
        [DllImport("libc", EntryPoint = "ptrace")]
        private static extern long ptrace(int request, int pid, long addr, long data);

        [DllImport("libc", EntryPoint = "getpid")]
        private static extern int GetPid();

        private const int PTRACE_ATTACH = 16;
        private const int PTRACE_DETACH = 17;
        private const int PTRACE_PEEKTEXT = 2;
        private const int PTRACE_POKETEXT = 4;

        private int _targetPid;
        private bool _attached;

        public bool AttachToProcess(int pid)
        {
            try
            {
                long result = ptrace(PTRACE_ATTACH, pid, 0, 0);
                if (result == 0)
                {
                    _targetPid = pid;
                    _attached = true;
                    System.Threading.Thread.Sleep(100);
                    return true;
                }
                return false;
            }
            catch
            {
                return false;
            }
        }

        public bool DetachFromProcess()
        {
            if (!_attached) return false;

            try
            {
                long result = ptrace(PTRACE_DETACH, _targetPid, 0, 0);
                _attached = false;
                return result == 0;
            }
            catch
            {
                return false;
            }
        }

        public long ReadMemory(long address)
        {
            if (!_attached) return 0;

            try
            {
                return ptrace(PTRACE_PEEKTEXT, _targetPid, address, 0);
            }
            catch
            {
                return 0;
            }
        }

        public bool WriteMemory(long address, long value)
        {
            if (!_attached) return false;

            try
            {
                long result = ptrace(PTRACE_POKETEXT, _targetPid, address, value);
                return result == 0;
            }
            catch
            {
                return false;
            }
        }

        public bool IsAttached => _attached;
        public int TargetPid => _targetPid;
    }
}
