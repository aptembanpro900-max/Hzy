using System;
using System.Runtime.InteropServices;
using Hz.Structs;

namespace Hz.Memory
{
    public class MemoryReader
    {
        [DllImport("kernel32.dll")]
        public static extern IntPtr OpenProcess(uint dwDesiredAccess, bool bInheritHandle, uint dwProcessId);
        
        [DllImport("kernel32.dll")]
        public static extern bool ReadProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, byte[] lpBuffer, uint nSize, out uint lpNumberOfBytesRead);
        
        [DllImport("kernel32.dll")]
        public static extern bool CloseHandle(IntPtr hObject);
        
        private const uint PROCESS_VM_READ = 0x0010;
        
        private IntPtr _processHandle;
        
        public bool Initialize(uint processId)
        {
            _processHandle = OpenProcess(PROCESS_VM_READ, false, processId);
            return _processHandle != IntPtr.Zero;
        }
        
        public byte[] ReadBytes(IntPtr address, uint size)
        {
            if (_processHandle == IntPtr.Zero) return null;
            
            byte[] buffer = new byte[size];
            ReadProcessMemory(_processHandle, address, buffer, size, out uint bytesRead);
            return bytesRead == size ? buffer : null;
        }
        
        public float ReadFloat(IntPtr address)
        {
            byte[] bytes = ReadBytes(address, 4);
            return bytes != null ? BitConverter.ToSingle(bytes, 0) : 0f;
        }
        
        public int ReadInt(IntPtr address)
        {
            byte[] bytes = ReadBytes(address, 4);
            return bytes != null ? BitConverter.ToInt32(bytes, 0) : 0;
        }
        
        public bool ReadBool(IntPtr address)
        {
            byte[] bytes = ReadBytes(address, 1);
            return bytes != null && bytes[0] != 0;
        }
        
        public Vector3 ReadVector3(IntPtr address)
        {
            byte[] bytes = ReadBytes(address, 12);
            if (bytes == null) return Vector3.Zero;
            
            return new Vector3(
                BitConverter.ToSingle(bytes, 0),
                BitConverter.ToSingle(bytes, 4),
                BitConverter.ToSingle(bytes, 8)
            );
        }
        
        public IntPtr ReadIntPtr(IntPtr address)
        {
            byte[] bytes = ReadBytes(address, IntPtr.Size);
            if (bytes == null) return IntPtr.Zero;
            
            return IntPtr.Size == 8 
                ? new IntPtr(BitConverter.ToInt64(bytes, 0))
                : new IntPtr(BitConverter.ToInt32(bytes, 0));
        }
        
        public void Cleanup()
        {
            if (_processHandle != IntPtr.Zero)
            {
                CloseHandle(_processHandle);
                _processHandle = IntPtr.Zero;
            }
        }
    }
    
    public static class Vector3Extensions
    {
        public static readonly Vector3 Zero = new Vector3(0, 0, 0);
    }
}