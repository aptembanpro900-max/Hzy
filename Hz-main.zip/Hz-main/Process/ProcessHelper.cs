using System;
using System.Diagnostics;
using Android.App;
using Android.Content;

namespace Hz.Process
{
    public class ProcessHelper
    {
        private const string GAME_PACKAGE = "com.catsbit.oxidesurvivalisland";

        public static bool LaunchGame(Context context)
        {
            try
            {
                var packageManager = context.PackageManager;
                var intent = packageManager.GetLaunchIntentForPackage(GAME_PACKAGE);
                
                if (intent != null)
                {
                    context.StartActivity(intent);
                    System.Threading.Thread.Sleep(2000);
                    return true;
                }
                return false;
            }
            catch
            {
                return false;
            }
        }

        public static int GetGamePid(Context context)
        {
            try
            {
                var activityManager = (ActivityManager)context.GetSystemService(Context.ActivityService);
                var processes = activityManager.GetRunningAppProcesses();

                foreach (var proc in processes)
                {
                    if (proc.ProcessName == GAME_PACKAGE)
                    {
                        return proc.Pid;
                    }
                }
                return -1;
            }
            catch
            {
                return -1;
            }
        }

        public static bool IsGameRunning(Context context)
        {
            return GetGamePid(context) != -1;
        }

        public static bool KillGame(Context context)
        {
            try
            {
                var activityManager = (ActivityManager)context.GetSystemService(Context.ActivityService);
                activityManager.KillBackgroundProcesses(GAME_PACKAGE);
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
