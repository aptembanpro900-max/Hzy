using Microsoft.Maui.Controls.Hosting;
using Microsoft.Maui.Hosting;

namespace Hz;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder
            .UseMauiApp<App>()
            .ConfigureFonts(fonts =>
            {
                fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
            })
            .ConfigureLifecycleEvents(events =>
            {
                #if __ANDROID__
                events.AddAndroid(android => android
                    .OnStart((activity) => OnAppStart())
                    .OnResume((activity) => OnAppResume()));
                #endif
            });

        return builder.Build();
    }

    private static void OnAppStart()
    {
    }

    private static void OnAppResume()
    {
    }
}
