using Microsoft.Maui.Controls;
using System.Collections.ObjectModel;
using Hz.Engine;
using Hz.Process;
using Android.Content;

namespace Hz.UI;

public partial class MainPage : ContentPage
{
    private GameEngine _gameEngine;
    private System.Threading.Timer _scanTimer;
    private ObservableCollection<string> _logMessages;

    public MainPage()
    {
        InitializeComponent();
        _logMessages = new ObservableCollection<string>();
        LogListView.ItemsSource = _logMessages;
        _gameEngine = new GameEngine();
    }

    private async void OnLaunchGameClicked(object sender, EventArgs e)
    {
        try
        {
            LaunchGameBtn.IsEnabled = false;
            LaunchGameBtn.Text = "⏳ Запуск...";

            AddLog("🎮 Запуск Oxide Survival Island...");

            if (ProcessHelper.LaunchGame(Application.Current.Handler.MauiContext.Context))
            {
                AddLog("✅ Игра запущена!");
                await Task.Delay(3000);

                int pid = ProcessHelper.GetGamePid(Application.Current.Handler.MauiContext.Context);
                if (pid != -1)
                {
                    AddLog($"📍 PID игры: {pid}");
                    LaunchGameBtn.Text = "🚀 Запустить Oxide Survival Island";
                    LaunchGameBtn.IsEnabled = true;
                }
            }
            else
            {
                AddLog("❌ Ошибка запуска игры!");
                LaunchGameBtn.Text = "🚀 Запустить Oxide Survival Island";
                LaunchGameBtn.IsEnabled = true;
            }
        }
        catch (Exception ex)
        {
            AddLog($"❌ Ошибка: {ex.Message}");
            LaunchGameBtn.Text = "🚀 Запустить Oxide Survival Island";
            LaunchGameBtn.IsEnabled = true;
        }
    }

    private async void OnStartCheatClicked(object sender, EventArgs e)
    {
        try
        {
            StartCheatBtn.IsEnabled = false;
            StartCheatBtn.Text = "⏳ Инициализация...";

            AddLog("🔍 Поиск процесса игры...");

            int pid = ProcessHelper.GetGamePid(Application.Current.Handler.MauiContext.Context);

            if (pid == -1)
            {
                AddLog("❌ Игра не запущена!");
                StartCheatBtn.Text = "▶️ Запустить Чит";
                StartCheatBtn.IsEnabled = true;
                return;
            }

            AddLog($"✅ Процесс найден: PID {pid}");
            AddLog("🔐 Подключение к памяти...");

            if (_gameEngine.Initialize(pid))
            {
                AddLog("✅ Подключено к памяти игры!");
                AddLog("🔄 Запуск сканирования...");

                _gameEngine.Start();
                _gameEngine.PlayersUpdated += OnPlayersUpdated;
                _gameEngine.ResourcesUpdated += OnResourcesUpdated;

                StartCheatBtn.Text = "⏹️ Остановить Чит";
                StartCheatBtn.IsEnabled = true;

                _scanTimer = new System.Threading.Timer(ScanCallback, null, 0, 500);
            }
            else
            {
                AddLog("❌ Ошибка подключения к памяти!");
                AddLog("💡 Убедитесь, что:");
                AddLog("   • На устройстве включена отладка USB");
                AddLog("   • Устройство рутировано (получены права root)");
                AddLog("   • Приложение запущено от администратора");

                StartCheatBtn.Text = "▶️ Запустить Чит";
                StartCheatBtn.IsEnabled = true;
            }
        }
        catch (Exception ex)
        {
            AddLog($"❌ Критическая ошибка: {ex.Message}");
            StartCheatBtn.Text = "▶️ Запустить Чит";
            StartCheatBtn.IsEnabled = true;
        }
    }

    private void OnStopCheatClicked(object sender, EventArgs e)
    {
        AddLog("🛑 Остановка чита...");
        _scanTimer?.Dispose();
        _gameEngine.Stop();
        AddLog("✅ Чит остановлен");

        StartCheatBtn.Text = "▶️ Запустить Чит";
        StartCheatBtn.IsEnabled = true;
    }

    private void ScanCallback(object state)
    {
        try
        {
            _gameEngine.ScanPlayers();
            _gameEngine.ScanResources();
        }
        catch
        {
        }
    }

    private void OnPlayersUpdated(object sender, PlayersUpdatedEventArgs e)
    {
        MainThread.BeginInvokeOnMainThread(() =>
        {
            AddLog($"👥 Найдено игроков: {e.Players.Count}");
            foreach (var player in e.Players)
            {
                AddLog($"   • Здоровье: {player.Health:F1}/{player.MaxHealth:F1}");
            }
        });
    }

    private void OnResourcesUpdated(object sender, ResourcesUpdatedEventArgs e)
    {
        MainThread.BeginInvokeOnMainThread(() =>
        {
            AddLog($"⛏️ Найдено ресурсов: {e.Resources.Count}");
        });
    }

    private void AddLog(string message)
    {
        MainThread.BeginInvokeOnMainThread(() =>
        {
            _logMessages.Insert(0, $"[{DateTime.Now:HH:mm:ss}] {message}");

            if (_logMessages.Count > 100)
            {
                _logMessages.RemoveAt(_logMessages.Count - 1);
            }
        });
    }

    private async void OnAboutClicked(object sender, EventArgs e)
    {
        await DisplayAlert(
            "ℹ️ О приложении",
            "Hz Cheat v1.0.0\n\n" +
            "Чит для Oxide Survival Island\n\n" +
            "Функции:\n" +
            "🎮 ESP для игроков\n" +
            "⛏️ Поиск ресурсов\n" +
            "🎯 Aimbot\n\n" +
            "⚠️ Используйте на свой риск!",
            "OK");
    }
}
