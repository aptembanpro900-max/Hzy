using System;
using System.Collections.Generic;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using Hz.Aimbot;
using Hz.ESP;
using Hz.Memory;
using Hz.Structs;

namespace Hz.UI
{
    public partial class MainWindow : Form
    {
        private MemoryReader _memoryReader;
        private ESPEngine _espEngine;
        private AimbotEngine _aimbotEngine;
        private Thread _scanThread;
        private volatile bool _running;
        
        private uint _playerListAddress = 0x400000;
        private uint _animalListAddress = 0x500000;
        private uint _containerListAddress = 0x600000;
        private uint _resourceListAddress = 0x700000;
        
        public MainWindow()
        {
            InitializeComponent();
            SetupUI();
        }
        
        private void SetupUI()
        {
            this.Text = "Hz - ESP/Aimbot Manager";
            this.Size = new Size(600, 700);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(30, 30, 30);
            this.ForeColor = Color.White;
            
            CreateMenuStrip();
            CreateControlPanel();
            CreateInfoPanel();
        }
        
        private void CreateMenuStrip()
        {
            MenuStrip menu = new MenuStrip();
            menu.BackColor = Color.FromArgb(40, 40, 40);
            menu.ForeColor = Color.White;
            
            ToolStripMenuItem fileMenu = new ToolStripMenuItem("Файл");
            fileMenu.DropDownItems.Add("Выход", null, (s, e) => Application.Exit());
            
            ToolStripMenuItem helpMenu = new ToolStripMenuItem("Помощь");
            helpMenu.DropDownItems.Add("О программе", null, (s, e) => MessageBox.Show("Hz v1.0\nESP/Aimbot Tool", "О программе"));
            
            menu.Items.Add(fileMenu);
            menu.Items.Add(helpMenu);
            
            this.MainMenuStrip = menu;
            this.Controls.Add(menu);
        }
        
        private void CreateControlPanel()
        {
            GroupBox controlGroup = new GroupBox()
            {
                Text = "Управление",
                Location = new Point(10, 30),
                Size = new Size(560, 200),
                ForeColor = Color.White
            };
            
            Button startBtn = new Button()
            {
                Text = "Запустить",
                Location = new Point(20, 30),
                Size = new Size(100, 40),
                BackColor = Color.Green,
                ForeColor = Color.White
            };
            startBtn.Click += (s, e) => StartEngine();
            
            Button stopBtn = new Button()
            {
                Text = "Остановить",
                Location = new Point(130, 30),
                Size = new Size(100, 40),
                BackColor = Color.Red,
                ForeColor = Color.White
            };
            stopBtn.Click += (s, e) => StopEngine();
            
            Label statusLabel = new Label()
            {
                Name = "StatusLabel",
                Text = "Статус: Остановлено",
                Location = new Point(20, 80),
                Size = new Size(200, 30),
                ForeColor = Color.Yellow
            };
            
            Label entityLabel = new Label()
            {
                Name = "EntityLabel",
                Text = "Найдено сущностей: 0",
                Location = new Point(20, 120),
                Size = new Size(200, 30),
                ForeColor = Color.Cyan
            };
            
            controlGroup.Controls.Add(startBtn);
            controlGroup.Controls.Add(stopBtn);
            controlGroup.Controls.Add(statusLabel);
            controlGroup.Controls.Add(entityLabel);
            
            this.Controls.Add(controlGroup);
        }
        
        private void CreateInfoPanel()
        {
            GroupBox espGroup = new GroupBox()
            {
                Text = "Настройки ESP",
                Location = new Point(10, 240),
                Size = new Size(560, 150),
                ForeColor = Color.White
            };
            
            CheckBox playersCheckbox = new CheckBox()
            {
                Name = "PlayersCheckbox",
                Text = "Показывать игроков",
                Location = new Point(20, 30),
                Checked = true,
                ForeColor = Color.White
            };
            
            CheckBox animalsCheckbox = new CheckBox()
            {
                Name = "AnimalsCheckbox",
                Text = "Показывать животных",
                Location = new Point(20, 60),
                Checked = true,
                ForeColor = Color.White
            };
            
            CheckBox containersCheckbox = new CheckBox()
            {
                Name = "ContainersCheckbox",
                Text = "Показывать контейнеры",
                Location = new Point(20, 90),
                Checked = true,
                ForeColor = Color.White
            };
            
            CheckBox resourcesCheckbox = new CheckBox()
            {
                Name = "ResourcesCheckbox",
                Text = "Показывать ресурсы",
                Location = new Point(300, 30),
                Checked = true,
                ForeColor = Color.White
            };
            
            espGroup.Controls.Add(playersCheckbox);
            espGroup.Controls.Add(animalsCheckbox);
            espGroup.Controls.Add(containersCheckbox);
            espGroup.Controls.Add(resourcesCheckbox);
            
            this.Controls.Add(espGroup);
            
            GroupBox aimbotGroup = new GroupBox()
            {
                Text = "Настройки Aimbot",
                Location = new Point(10, 400),
                Size = new Size(560, 150),
                ForeColor = Color.White
            };
            
            CheckBox aimbotCheckbox = new CheckBox()
            {
                Name = "AimbotCheckbox",
                Text = "Включить Aimbot",
                Location = new Point(20, 30),
                ForeColor = Color.White
            };
            
            Label fovLabel = new Label()
            {
                Text = "FOV:",
                Location = new Point(20, 60),
                Size = new Size(50, 20),
                ForeColor = Color.White
            };
            
            NumericUpDown fovValue = new NumericUpDown()
            {
                Name = "FOVValue",
                Location = new Point(80, 60),
                Size = new Size(60, 20),
                Value = 45,
                Minimum = 1,
                Maximum = 180
            };
            
            Label boneLabel = new Label()
            {
                Text = "Целевая кость:",
                Location = new Point(20, 90),
                Size = new Size(100, 20),
                ForeColor = Color.White
            };
            
            ComboBox boneCombo = new ComboBox()
            {
                Name = "BoneCombo",
                Location = new Point(130, 90),
                Size = new Size(100, 20),
                Items = { "Head", "Neck", "Spine", "LeftArm", "RightArm" },
                SelectedIndex = 0
            };
            
            aimbotGroup.Controls.Add(aimbotCheckbox);
            aimbotGroup.Controls.Add(fovLabel);
            aimbotGroup.Controls.Add(fovValue);
            aimbotGroup.Controls.Add(boneLabel);
            aimbotGroup.Controls.Add(boneCombo);
            
            this.Controls.Add(aimbotGroup);
        }
        
        private void StartEngine()
        {
            try
            {
                _memoryReader = new MemoryReader();
                _espEngine = new ESPEngine(_memoryReader);
                _aimbotEngine = new AimbotEngine(_memoryReader);
                
                _espEngine.Start();
                _running = true;
                
                _scanThread = new Thread(ScanLoop)
                {
                    IsBackground = true
                };
                _scanThread.Start();
                
                UpdateStatusLabel("Статус: Запущено", Color.LimeGreen);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        
        private void StopEngine()
        {
            _running = false;
            if (_espEngine != null) _espEngine.Stop();
            if (_memoryReader != null) _memoryReader.Cleanup();
            
            UpdateStatusLabel("Статус: Остановлено", Color.Yellow);
        }
        
        private void ScanLoop()
        {
            while (_running)
            {
                try
                {
                    _espEngine.ScanPlayers(new IntPtr((long)_playerListAddress));
                    _espEngine.ScanAnimals(new IntPtr((long)_animalListAddress));
                    _espEngine.ScanContainers(new IntPtr((long)_containerListAddress));
                    _espEngine.ScanResources(new IntPtr((long)_resourceListAddress));
                    
                    int entityCount = _espEngine.EntityCount;
                    UpdateEntityLabel($"Найдено сущностей: {entityCount}");
                    
                    Thread.Sleep(100);
                }
                catch
                {
                    Thread.Sleep(100);
                }
            }
        }
        
        private void UpdateStatusLabel(string text, Color color)
        {
            if (InvokeRequired)
            {
                Invoke(new Action(() => UpdateStatusLabel(text, color)));
                return;
            }
            
            Label statusLabel = this.Controls.Find("StatusLabel", false).FirstOrDefault() as Label;
            if (statusLabel != null)
            {
                statusLabel.Text = text;
                statusLabel.ForeColor = color;
            }
        }
        
        private void UpdateEntityLabel(string text)
        {
            if (InvokeRequired)
            {
                Invoke(new Action(() => UpdateEntityLabel(text)));
                return;
            }
            
            Label entityLabel = this.Controls.Find("EntityLabel", false).FirstOrDefault() as Label;
            if (entityLabel != null)
            {
                entityLabel.Text = text;
            }
        }
        
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            StopEngine();
            base.OnFormClosing(e);
        }
    }
}