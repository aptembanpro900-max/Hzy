# Hz - ESP/Aimbot Tool

## Описание
Hz - это полнофункциональный инструмент для работы с ESP (видимость всех объектов) и Aimbot (автоматическое прицеливание) в играх на основе Unity.

## Функционал

### 🎮 ESP (Entity Scanner Protocol)
- **Сканирование игроков** - отслеживание всех живых игроков
- **Сканирование животных** - отслеживание враждебной и дружественной фауны
- **Сканирование контейнеров** - поиск ящиков, сундуков, хранилищ
- **Сканирование ресурсов** - локализация руды, дерева и других ресурсов

### 🎯 Aimbot
- **Автоматическое прицеливание** на игроков
- **Множественные точки целевания**:
  - Голова (лучший результат)
  - Шея
  - Позвоночник/Грудь
  - Руки
  - Ноги
- **Настраиваемые параметры**:
  - FOV (поле зрения) - 1°-180°
  - Плавность наведения
  - Максимальное расстояние

### 💾 Архитектура

```
Hz/
├── Offsets/              # Оффсеты памяти для игровых объектов
│   ├── PlayerOffsets.cs
│   ├── AimbotOffsets.cs
│   ├── AnimalOffsets.cs
│   ├── NPCOffsets.cs
│   ├── ContainerOffsets.cs
│   └── ResourceOffsets.cs
├── Structs/              # Структуры данных
│   ├── Vector3.cs
│   └── Entity.cs
├── Memory/               # Работа с памятью процесса
│   └── MemoryReader.cs
├── Scanning/             # Сканирование и анализ
│   └── OffsetScanner.cs
├── ESP/                  # Система ESP
│   └── ESPEngine.cs
├── Aimbot/               # Система Aimbot
│   └── AimbotEngine.cs
├── UI/                   # Пользовательский интерфейс
│   └── MainWindow.cs
└── Program.cs            # Точка входа
```

## Требования
- .NET 8.0 или выше
- Windows 7 и выше
- Права администратора для доступа к памяти процесса

## Компиляция

```bash
# Восстановление зависимостей
dotnet restore

# Компиляция
dotnet build -c Release

# Запуск
dotnet run
```

## Использование

1. Запустите приложение
2. Нажмите кнопку "Запустить" для начала сканирования
3. Выберите нужные опции ESP
4. Настройте параметры Aimbot
5. Нажмите "Остановить" для завершения

## Оффсеты памяти

| Объект | Параметр | Оффсет | Тип | Описание |
|--------|----------|--------|-----|----------|
| Player | Position | 0x18 | Vector3 | XYZ координаты |
| Player | Health | 0x140 | float | Текущее здоровье |
| Player | MaxHealth | 0x144 | float | Максимальное здоровье |
| Player | Head Bone | 0x158 | Transform | Кость головы |
| Player | Chest Bone | 0x160 | Transform | Кость груди |
| Animal | Position | 0x18 | Vector3 | Позиция животного |
| Animal | Species | 0x200 | enum | Тип животного |
| Container | Type | 0x280 | enum | Тип ящика |
| Container | IsLocked | 0x290 | bool | Заблокирован? |
| Resource | Type | 0x2C0 | enum | Тип руды |
| Resource | Amount | 0x2C8 | int | Количество |

## Структура класса PlayerOffsets

```csharp
public class PlayerOffsets
{
    public const uint Position = 0x18;        // Vector3 - координаты
    public const uint Health = 0x140;         // float - здоровье
    public const uint MaxHealth = 0x144;      // float - макс здоровье
    public const uint IsDead = 0x148;         // bool - жив ли
    public const uint Head = 0x158;           // Transform - голова
    public const uint Chest = 0x160;          // Transform - грудь
    public const uint Neck = 0x168;           // Transform - шея
}
```

## Лицензия
Часто используется в образовательных целях для изучения архитектуры игр.

## ⚠️ Отказ от ответственности
Этот инструмент предоставляется в образовательных целях. Использование читов в онлайн-игры может привести к блокировке аккаунта.
