# Oxide Survival Island - Offsets Analyzer
## Complete Guide for ESP, Aimbot, Animals, NPCs, Resources, и Containers

---

## 📋 ОСНОВНЫЕ СТРУКТУРЫ И OFFSETS

### 1. 🎮 PLAYER ESP OFFSETS

```csharp
// BasePlayer структура
public class PlayerOffsets
{
    // Основная позиция
    public const uint Position = 0x18;           // Vector3 - координаты X, Y, Z
    public const uint Transform = 0x10;          // Transform компонент
    
    // Здоровье и статус
    public const uint Health = 0x140;            // float - текущее здоровье
    public const uint MaxHealth = 0x144;         // float - максимальное здоровье
    public const uint IsDead = 0x148;            // bool - жив ли игрок
    
    // Кости скелета (для aim)
    public const uint BoneTransforms = 0x150;    // массив Transform для костей
    public const uint Head = 0x158;              // Bone_Head
    public const uint Chest = 0x160;             // Bone_Chest
    public const uint Neck = 0x168;              // Bone_Neck
    
    // Видимость
    public const uint PlayerModel = 0x170;       // GameObject для визуализации
    public const uint IsVisible = 0x178;         // bool
    public const uint Distance = 0x180;          // float - расстояние до игрока
}
```

### 2. 🔍 AIMBOT OFFSETS (BONE STRUCTURE)

```csharp
public class AimbotOffsets
{
    // Кости персонажа для наведения
    public const uint SkeletonRoot = 0x150;
    
    // Основные точки прицеливания
    public const uint Head_Bone = 0x158;         // Голова (лучшая точка)
    public const uint Neck_Bone = 0x168;         // Шея
    public const uint Spine_Bone = 0x160;        // Позвоночник/Грудь
    public const uint LeftArm_Bone = 0x180;      // Левая рука
    public const uint RightArm_Bone = 0x188;     // Правая рука
    public const uint LeftLeg_Bone = 0x190;      // Левая нога
    public const uint RightLeg_Bone = 0x198;     // Правая нога
    
    // FOV для aimbot
    public const float AimbotFOV = 45f;          // градусы
    public const float MaxDistance = 500f;       // максимальное расстояние
}
```

### 3. 🐻 ANIMALS ESP OFFSETS

```csharp
public class AnimalOffsets
{
    // Базовая структура животного
    public const uint AnimalBase = 0x0;
    public const uint Position = 0x18;           // Vector3 позиция
    public const uint Health = 0x140;            // float - здоровье
    public const uint Species = 0x200;           // enum - тип животного
    
    // Типы животных
    public enum AnimalType
    {
        Bear = 1,
        Wolf = 2,
        Deer = 3,
        Chicken = 4,
        Boar = 5,
        Horse = 6
    }
}
```

### 4. 👹 NPC ESP OFFSETS

```csharp
public class NPCOffsets
{
    public const uint Position = 0x18;           // Vector3
    public const uint Health = 0x140;            // float
    public const uint NPCType = 0x210;           // enum - тип NPC
    public const uint Brain = 0x220;             // AI мозг
    public const uint Inventory = 0x230;         // Инвентарь NPC
    
    // Типы NPC
    public enum NPCType
    {
        Scientist = 1,
        Bandit = 2,
        Murderer = 3,
        Guard = 4
    }
}
```

### 5. 📦 CONTAINER ESP OFFSETS (ЯЩИКИ)

```csharp
public class ContainerOffsets
{
    public const uint Position = 0x18;           // Vector3
    public const uint ContainerType = 0x280;     // enum - тип контейнера
    public const uint IsLocked = 0x290;          // bool
    public const uint Inventory = 0x2A0;         // InventoryContainer
    public const uint ItemsCount = 0x2A8;        // int
    
    // Типы контейнеров
    public enum ContainerType
    {
        WoodenBox = 1,           // Деревянный ящик
        MilitaryCrate = 2,       // Военный ящик
        ToolBox = 3,             // Ящик с инструментами
        EliteCrate = 4,          // Элитный ящик
        Fridge = 5,              // Холодильник
        Furnace = 6              // Печь
    }
}
```

### 6. ⛏️ RESOURCES ESP OFFSETS (РУДА И РЕСУРСЫ)

```csharp
public class ResourceOffsets
{
    public const uint Position = 0x18;           // Vector3
    public const uint ResourceType = 0x2C0;      // enum - тип ресурса
    public const uint Amount = 0x2C8;            // int - количество
    public const uint Health = 0x2CC;            // float - здоровье ноды
    
    // Типы ресурсов
    public enum ResourceType
    {
        Stone = 1,               // Камень
        Wood = 2,                // Дерево
        Sulfur = 3,              // Серная руда (Sulfur Ore)
        IronOre = 4,             // Железная руда (Iron Ore)
        Copper = 5,              // Медь
        Crude = 6,               // Нефть
        Metal = 7                // Металлический фрагмент
    }
}
```

---

## 🔧 КОД ДЛЯ ПОИСКА OFFSETS

### Автоматический сканер структур

```csharp
using System;
using System.Collections.Generic;

public class OffsetScanner
{
    /// <summary>
    /// Сканирует дампы и находит Player классы
    /// </summary>
    public static List<string> FindPlayerClasses(string dumpContent)
    {
        var results = new List<string>();
        string[] lines = dumpContent.Split('\n');
        
        foreach (var line in lines)
        {
            if (line.Contains("class") && line.Contains("Player"))
            {
                results.Add(line);
            }
        }
        
        return results;
    }
    
    /// <summary>
    /// Находит все Entity классы (Animal, NPC, Container)
    /// </summary>
    public static List<string> FindEntityClasses(string dumpContent)
    {
        var results = new List<string>();
        string[] lines = dumpContent.Split('\n');
        
        var entityTypes = new[] 
        { 
            "BaseEntity", "Animal", "NPC", "BaseCombatEntity",
            "StorageContainer", "LootContainer", "ResourceDispenser"
        };
        
        foreach (var line in lines)
        {
            foreach (var entityType in entityTypes)
            {
                if (line.Contains("class") && line.Contains(entityType))
                {
                    results.Add(line);
                }
            }
        }
        
        return results;
    }
    
    /// <summary>
    /// Находит Transform и Position определения
    /// </summary>
    public static Dictionary<string, string> FindPositionStructures(string dumpContent)
    {
        var results = new Dictionary<string, string>();
        string[] lines = dumpContent.Split('\n');
        
        for (int i = 0; i < lines.Length; i++)
        {
            if (lines[i].Contains("position") || lines[i].Contains("Position"))
            {
                // Ищем контекст вокруг этой строки
                string context = $"{(i > 0 ? lines[i-1] : "")} | {lines[i]} | {(i < lines.Length-1 ? lines[i+1] : "")}";
                results.Add($"Line_{i}", context);
            }
        }
        
        return results;
    }
}
```

---

## 📊 ТАБЛИЦА ВСЕХ OFFSETS (ШПАРГАЛКА)

| Категория | Параметр | Примерный Offset | Тип | Описание |
|-----------|----------|------------------|-----|----------|
| **Player** | Position | 0x18 | Vector3 | XYZ координаты |
| **Player** | Health | 0x140 | float | Текущее здоровье |
| **Player** | MaxHealth | 0x144 | float | Макс здоровье |
| **Player** | Head Bone | 0x158 | Transform | Кость головы |
| **Player** | Chest Bone | 0x160 | Transform | Кость груди |
| **Animal** | Position | 0x18 | Vector3 | Позиция животного |
| **Animal** | Species | 0x200 | enum | Тип животного |
| **NPC** | Position | 0x18 | Vector3 | Позиция NPC |
| **Container** | Type | 0x280 | enum | Тип ящика |
| **Container** | IsLocked | 0x290 | bool | Заблокирован? |
| **Resource** | Type | 0x2C0 | enum | Тип руды |
| **Resource** | Amount | 0x2C8 | int | Количество |

---

## 🛠️ ИНСТРУКЦИЯ ПО ПРИМЕНЕНИЮ

### Шаг 1: Определение базовых адресов
```csharp
// Находим адрес LocalPlayer
IntPtr playerInstance = FindLocalPlayer();

// Читаем позицию
Vector3 playerPos = ReadVector3(playerInstance + PlayerOffsets.Position);
```

### Шаг 2: Сканирование всех Entity
```csharp
// Находим список всех игроков
List<IntPtr> allPlayers = ScanForPlayers(0x400000, 0x2000000);

// Находим животных
List<IntPtr> animals = ScanForAnimals(0x400000, 0x2000000);

// Находим ящики
List<IntPtr> containers = ScanForContainers(0x400000, 0x2000000);
```

### Шаг 3: Отрисовка ESP
```csharp
foreach (var player in allPlayers)
{
    Vector3 pos = ReadVector3(player + PlayerOffsets.Position);
    float health = ReadFloat(player + PlayerOffsets.Health);
    
    // Отрисовываем бокс на экране
    DrawESPBox(pos, "Player [" + health + " HP]");
}
```

---

## ⚠️ ВАЖНЫЕ ЗАМЕЧАНИЯ

1. **Оффсеты могут отличаться** в зависимости от версии игры
2. **Используйте dumpAnalyzer.exe** для точного поиска в файлах dump_part_*
3. **Проверяйте типы данных** перед чтением из памяти
4. **Добавьте проверки на валидность** адресов перед доступом

---

## 📁 ФАЙЛЫ В РЕПОЗИТОРИИ

- `dump_part_aa` - часть 1 дампа (20 МБ)
- `dump_part_ab` - часть 2 дампа (20 МБ)
- `dump_part_ac` - часть 3 дампа (20 МБ)
- `dump_part_ad` - часть 4 дампа (6.4 МБ)

**Общий размер: ~67 МБ**

---

Создано для одиночной игры "Oxide Survival Island" v1.18.00
