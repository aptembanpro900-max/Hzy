using System;
using System.Collections.Generic;
using Hz.Memory;
using Hz.Offsets;

namespace Hz.Engine
{
    public class GameEngine
    {
        private MemoryAccessor _memory;
        private int _gamePid;
        private bool _running;
        private List<Player> _players;
        private List<Resource> _resources;

        public event EventHandler<PlayersUpdatedEventArgs> PlayersUpdated;
        public event EventHandler<ResourcesUpdatedEventArgs> ResourcesUpdated;

        public GameEngine()
        {
            _memory = new MemoryAccessor();
            _players = new List<Player>();
            _resources = new List<Resource>();
        }

        public bool Initialize(int gamePid)
        {
            _gamePid = gamePid;
            return _memory.AttachToProcess(gamePid);
        }

        public void Start()
        {
            _running = true;
        }

        public void Stop()
        {
            _running = false;
            _memory.DetachFromProcess();
        }

        public void ScanPlayers()
        {
            if (!_memory.IsAttached) return;

            _players.Clear();

            try
            {
                long playerListPtr = _memory.ReadMemory(GameOffsets.PlayerListPtr);
                if (playerListPtr == 0) return;

                for (int i = 0; i < 100; i++)
                {
                    long playerPtr = _memory.ReadMemory(playerListPtr + (i * 8));
                    if (playerPtr == 0) continue;

                    var player = new Player
                    {
                        Address = playerPtr,
                        Health = ReadFloat(_memory, playerPtr + GameOffsets.HealthOffset),
                        MaxHealth = ReadFloat(_memory, playerPtr + GameOffsets.MaxHealthOffset),
                        IsAlive = !ReadBool(_memory, playerPtr + GameOffsets.IsDeadOffset)
                    };

                    if (player.IsAlive && player.Health > 0)
                    {
                        _players.Add(player);
                    }
                }

                PlayersUpdated?.Invoke(this, new PlayersUpdatedEventArgs { Players = _players });
            }
            catch
            {
            }
        }

        public void ScanResources()
        {
            if (!_memory.IsAttached) return;

            _resources.Clear();

            try
            {
                long resourceListPtr = _memory.ReadMemory(0x0); // Нужно найти реальный указатель

                for (int i = 0; i < 500; i++)
                {
                    long resourcePtr = _memory.ReadMemory(resourceListPtr + (i * 8));
                    if (resourcePtr == 0) continue;

                    var resource = new Resource
                    {
                        Address = resourcePtr,
                        Type = (ResourceType)_memory.ReadMemory(resourcePtr + GameOffsets.ResourceTypeOffset),
                        Amount = (int)_memory.ReadMemory(resourcePtr + GameOffsets.ResourceAmountOffset)
                    };

                    _resources.Add(resource);
                }

                ResourcesUpdated?.Invoke(this, new ResourcesUpdatedEventArgs { Resources = _resources });
            }
            catch
            {
            }
        }

        public List<Player> GetPlayers() => new List<Player>(_players);
        public List<Resource> GetResources() => new List<Resource>(_resources);

        private float ReadFloat(MemoryAccessor memory, long address)
        {
            long value = memory.ReadMemory(address);
            return BitConverter.ToSingle(BitConverter.GetBytes(value), 0);
        }

        private bool ReadBool(MemoryAccessor memory, long address)
        {
            long value = memory.ReadMemory(address);
            return value != 0;
        }
    }

    public class Player
    {
        public long Address { get; set; }
        public float Health { get; set; }
        public float MaxHealth { get; set; }
        public bool IsAlive { get; set; }
    }

    public class Resource
    {
        public long Address { get; set; }
        public ResourceType Type { get; set; }
        public int Amount { get; set; }
    }

    public class PlayersUpdatedEventArgs : EventArgs
    {
        public List<Player> Players { get; set; }
    }

    public class ResourcesUpdatedEventArgs : EventArgs
    {
        public List<Resource> Resources { get; set; }
    }
}
