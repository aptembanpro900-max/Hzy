using System;
using System.Collections.Generic;
using System.Linq;
using Hz.Memory;
using Hz.Offsets;
using Hz.Structs;

namespace Hz.Aimbot
{
    public class AimbotEngine
    {
        private MemoryReader _memoryReader;
        private List<Entity> _targets;
        private Entity _currentTarget;
        private readonly object _lockObject = new object();
        
        public bool IsEnabled { get; set; }
        public float FOV { get; set; }
        public float Smoothness { get; set; }
        public AimbotOffsets.BoneType TargetBone { get; set; }
        
        public AimbotEngine(MemoryReader memoryReader)
        {
            _memoryReader = memoryReader;
            _targets = new List<Entity>();
            FOV = AimbotOffsets.AimbotFOV;
            Smoothness = 1.0f;
            TargetBone = AimbotOffsets.BoneType.Head;
        }
        
        public void UpdateTargets(List<Entity> availableEntities)
        {
            lock (_lockObject)
            {
                _targets = availableEntities.Where(e => e.Type == EntityType.Player && e.IsAlive).ToList();
            }
        }
        
        public Entity FindClosestTarget(Vector3 playerPosition)
        {
            if (!IsEnabled) return null;
            
            lock (_lockObject)
            {
                if (_targets.Count == 0) return null;
                
                var closestTarget = _targets.OrderBy(t => playerPosition.Distance(t.Position)).FirstOrDefault();
                
                if (closestTarget != null && playerPosition.Distance(closestTarget.Position) <= AimbotOffsets.MaxDistance)
                {
                    _currentTarget = closestTarget;
                    return closestTarget;
                }
                
                return null;
            }
        }
        
        public Vector3 GetTargetBonePosition(Entity target)
        {
            if (target?.Address == IntPtr.Zero) return Vector3.Zero;
            
            uint boneOffset = TargetBone switch
            {
                AimbotOffsets.BoneType.Head => AimbotOffsets.Head_Bone,
                AimbotOffsets.BoneType.Neck => AimbotOffsets.Neck_Bone,
                AimbotOffsets.BoneType.Spine => AimbotOffsets.Spine_Bone,
                AimbotOffsets.BoneType.LeftArm => AimbotOffsets.LeftArm_Bone,
                AimbotOffsets.BoneType.RightArm => AimbotOffsets.RightArm_Bone,
                AimbotOffsets.BoneType.LeftLeg => AimbotOffsets.LeftLeg_Bone,
                AimbotOffsets.BoneType.RightLeg => AimbotOffsets.RightLeg_Bone,
                _ => AimbotOffsets.Head_Bone
            };
            
            return _memoryReader.ReadVector3(target.Address + boneOffset);
        }
        
        public Entity GetCurrentTarget()
        {
            lock (_lockObject)
            {
                return _currentTarget;
            }
        }
        
        public void ClearTarget()
        {
            lock (_lockObject)
            {
                _currentTarget = null;
            }
        }
    }
}