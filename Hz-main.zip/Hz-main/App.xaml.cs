using Microsoft.Maui.Controls;
using Hz.UI;

namespace Hz;

public partial class App : Application
{
    public App()
    {
        InitializeComponent();

        MainPage = new NavigationPage(new MainPage())
        {
            BarBackgroundColor = Color.FromArgb("#1a1a2e"),
            BarTextColor = Color.FromArgb("#00ff96")
        };
    }
}
